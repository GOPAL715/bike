from catboost import CatBoostClassifier
from flask import Flask, render_template, request
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score

webapp=Flask(__name__)







@webapp.route('/')
def index():
    return render_template('index.html')
@webapp.route('/load',methods=["GET","POST"])
def load():
    global df,dataset
    if request.method=="POST":
        file=request.files['file']
        df=pd.read_csv(file)
        dataset=df.head(100)
        msg='Data Loaded Successfully'
        return render_template('load.html',msg=msg)
    return render_template('load.html')

@webapp.route('/view')
def view():
    print(dataset)
    print(dataset.head(2))
    print(dataset.columns)
    return render_template('view.html', columns=dataset.columns.values, rows=dataset.values.tolist())
@webapp.route('/preprocess',methods=['POST','GET'])
def preprocess():
    global X,y,X_train, X_test, y_train, y_test
    if request.method=="POST":
        size=int(request.form['split'])
        size=size/100
        df.dropna(axis=0, inplace=True)
        df.drop_duplicates(inplace=True)
        df['PM2.5'] = df['PM10'].apply(lambda x: x * 0.75 - 1.72)
        df['Pollution'] = df['PM2.5'].apply(lambda x: 1 if x > 115 else 0)
        # df.to_csv('Airpolutifinaldataset.csv')
        # df.to_csv('preprocessed.csv', index=False)
        le = LabelEncoder()
        df['City'] = le.fit_transform(df['City'])
        X = df.drop(['Pollution','Date'], axis=1)
        y = df['Pollution']
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=size, random_state=42)
        print(X_train.columns)
        return render_template('preprocess.html',msg='Data Preprocessed and It Splits Successfully')
    return render_template('preprocess.html')

@webapp.route('/model',methods=['POST','GET'])
def model():
    try:
        if request.method=="POST":
            print('ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc')
            s=int(request.form['algo'])
            if s==0:
                return render_template('model.html',msg='Please Choose an Algorithm to Train')
            elif s==1:
                print('aaaaaaaaaaaaaaaaaaaaabbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb')
                clf = LogisticRegression().fit(X_train, y_train)
                pred = clf.predict(X_test)
                ac_lr = accuracy_score(y_test, pred)
                ac_lr = ac_lr * 100
                print('aaaaaaaaaaaaaaaaaaaaaaaaa')
                msg = 'The accuracy obtained by Logistic Regression is ' + str(ac_lr) + str('%')
                return render_template('model.html', msg=msg)
            elif s==2:
                rf=RandomForestClassifier(n_estimators=10,min_samples_leaf=1, random_state=10).fit(X_train,y_train)
                rf_pred=rf.predict(X_test)
                ac_rf = accuracy_score(y_test, rf_pred)
                ac_rf=ac_rf*100
                msg = 'The accuracy obtained by Random Forest is ' + str(ac_rf) + str('%')
                return render_template('model.html', msg=msg)
            elif s==3:
                dt=DecisionTreeClassifier(min_samples_leaf=1, random_state=10,).fit(X_train,y_train)
                dt_pred=dt.predict(X_test)
                ac_dt = accuracy_score(y_test, dt_pred)
                ac_dt=ac_dt*100
                msg = 'The accuracy obtained by Decision Tree is ' + str(ac_dt) + str('%')
                return render_template('model.html', msg=msg)
            elif s==4:
                cb=CatBoostClassifier().fit(X_train,y_train)
                cb_pred=cb.predict(X_test)
                cb_dt = accuracy_score(y_test, cb_pred)
                cb_dt=cb_dt*100
                msg = 'The accuracy obtained by CatBoost Classifier is ' + str(cb_dt) + str('%')
                return render_template('model.html', msg=msg)
            return render_template('model.html')
        return render_template('model.html')
    except:
        msg='Please Upload the required dataset'
        return render_template('load.html',msg=msg)
@webapp.route('/prediction',methods=["GET","POST"])
def prediction():
    try:

        if request.method=="POST":

            f1=int(request.form['city'])
            f2=request.form['PM2.5']
            f3=request.form['PM10']
            f4=request.form['NO']
            f5=request.form['NO2']
            f6=request.form['NOx']
            f7 = request.form['NH3']
            f8 = request.form['CO']
            f9 = request.form['SO2']
            f10 = request.form['O3']
            f11 = request.form['Benzene']
            f12 = request.form['Toluene']
            f13 = request.form['Xylene']
            li=[f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12,f13]
            model=DecisionTreeClassifier()
            model.fit(X_train,y_train)
            result=model.predict([li])
            print(result)
            if result==0:
                msg='High Pollution'
            else:
                msg='Low Pollution'
            return render_template('prediction.html',msg=msg)
        return render_template('prediction.html')
    except:
        return render_template('prediction.html',msg="Please Fill all the Requirements")

if __name__=='__main__':
    webapp.run(debug=True)
